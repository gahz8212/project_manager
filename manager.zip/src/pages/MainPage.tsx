import React from "react";

const MainPage = () => {
  return <div>Main</div>;
};

export default MainPage;
