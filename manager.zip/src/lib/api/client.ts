import axios from "axios";
const client = axios.create();
export default client;
