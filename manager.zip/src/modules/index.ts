import { all } from "redux-saga/effects";
import { combineReducers } from "redux";
import auth, { authSaga } from "./auth/index";
import user, { userSaga } from "./user/index";

const rootReducer = combineReducers({ auth, user });
export function* rootSaga() {
  yield all([authSaga(), userSaga()]);
}
export default rootReducer;
export type RootState = ReturnType<typeof rootReducer>;
